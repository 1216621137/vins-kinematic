#include "bifactor.h"
