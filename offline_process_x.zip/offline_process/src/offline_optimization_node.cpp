#include <cstdio>
#include <vector>
#include <ros/ros.h>
#include <fstream>
#include <eigen3/Eigen/Dense>
#include <ceres/ceres.h>
#include <fstream>
#include "factor.h"
#include <opencv2/opencv.hpp>
#include <opencv2/core/eigen.hpp>
using namespace std;
using namespace Eigen;

string setting_file;
string save_path;
int e2;//残差的形式
int tr;//是否估计外参的标志位
Vector3d Xoi ;
double para_ET[7];
double delta_xio[3] = {0, 0, 0};
Matrix3d R;
Vector3d t;
Matrix3d Simq = Matrix3d::Identity();
Vector3d Simt = Vector3d::Zero();
Matrix3d q_last = Matrix3d::Identity();
Vector3d  p_last = Vector3d::Zero();
double weight;
double weight2;
double weight3;
int seq_n = 5;
int  MAX_ITERATION_NUMBER;
int if_lossfunction;
int if_xoi;
template<typename T>
T readParam(ros::NodeHandle &n, string name){
    T ans;
    //使用getParam函数读取launch里的参数
    if(n.getParam(name, ans))
    {
        ROS_INFO_STREAM("Loaded "<<name<<": "<<ans);
    }
    else{
        ROS_ERROR_STREAM("Failed to load "<<name);
        n.shutdown();
    }
    return ans;
}

struct Data
{
    Data(FILE *f)
    {
        if (fscanf(f, " %lf,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f", &t,
               &px, &py, &pz,
               &qw, &qx, &qy, &qz,
               &vx, &vy, &vz,
               &wx, &wy, &wz,
               &ax, &ay, &az) != EOF)
        {
            t /= 1e9;
        }
    }
    double t;
    float px, py, pz;
    float qw, qx, qy, qz;
    float vx, vy, vz;
    float wx, wy, wz;//原始数据中，这个值是零偏，我改了源码，输出了对应时刻的角速度
    float ax, ay, az;
};
//存数据的vector,child应该是只用关键帧的数据
vector<Data> center_path, child_path;
vector<Data>::iterator center;
vector<Data>::iterator child;
vector<Data>::iterator child_flag;
vector<Data>::iterator child_last;
int n = 0;
int number = 10000000;//default value
int iterater_num = 0;
double Time =1;
double cur_t = 0;
double last_t =0;
double Frequence = 10;//default value
int k =0;
int data_noise;
int Align ;
int processnumber;
int all_process;
int back_n;
int propagate;

int process(double para_Pose[][7], double para_SpeedBias[][9], double euler_array[][3],
                                    double rect_Pose[][7], double rect_SpeedBias[][9] )
{      
    k=0;
    ROS_INFO_STREAM("iterator time: "<<(++iterater_num));
    ROS_INFO_STREAM("start iterator index : "<<child - child_path.begin());
    ROS_INFO_STREAM("'n' index : "<<n);
    ROS_INFO_STREAM("child_last index : "<<child_last - child_path.begin());
    ceres::Problem problem;
    ceres::LossFunction *loss_function;
    loss_function = new ceres::HuberLoss(0.1);
    
    if( (int)(child_path.end() - child_last+1)  < number){
        child_flag = child_path.end();
    }else{
        child_flag = child_last +1 + number;
    }
    ROS_INFO_STREAM("end index: "<<child_flag - child_path.begin());
    if(tr==1){
        ceres::LocalParameterization *local_parameterization = new PoseLocalParameterization();
        problem.AddParameterBlock(para_ET, 7, local_parameterization);
    }
    if(if_xoi == 1){
        problem.AddParameterBlock(delta_xio, 3);
    }
    for(int i = child-child_path.begin(); i<child_flag-child_path.begin(); i++)
    {
        para_Pose[i][0] = (child+i)->px; para_Pose[i][1] = (child+i)->py; para_Pose[i][2] = (child+i)->pz;
        para_Pose[i][3] = (child+i)->qx; para_Pose[i][4] = (child+i)->qy; para_Pose[i][5] = (child+i)->qz; para_Pose[i][6] = (child+i)->qw;
        para_SpeedBias[i][0] = (child+i)->vx; para_SpeedBias[i][1] =(child+i)->vy; para_SpeedBias[i][2] = (child+i)->vz;
        
        ceres::LocalParameterization *local_parameterization = new PoseLocalParameterization();
        problem.AddParameterBlock(para_Pose[i], 7, local_parameterization);
        problem.AddParameterBlock(para_SpeedBias[i], 3);
    }
    if(child != child_path.begin() && back_n == 0){//每次优化，把起点前一个也加到优化器里
        para_Pose[n][0] = (child-1)->px; para_Pose[n][1] =(child-1)->py; para_Pose[n][2] = (child-1)->pz;
        para_Pose[n][3] = (child-1)->qx; para_Pose[n][4] = (child-1)->qy; para_Pose[n][5] =(child-1)->qz; para_Pose[n][6] = (child-1)->qw;
        para_SpeedBias[n][0] = (child-1)->vx; para_SpeedBias[n][1] = (child-1)->vy; para_SpeedBias[n][2] = (child-1)->vz;
    
        ceres::LocalParameterization *local_parameterization = new PoseLocalParameterization();
        problem.AddParameterBlock(para_Pose[n], 7, local_parameterization);//n是上次优化结束的位置
        problem.AddParameterBlock(para_SpeedBias[n], 3);
    }
   
    if((all_process == 1 || child_last+1-child_path.begin()<=back_n) && child_last != child_path.begin()){
                    ROS_INFO("set constant : 0");
                    problem.SetParameterBlockConstant(para_Pose[0]);
                    problem.SetParameterBlockConstant(para_SpeedBias[0]); 
    }
    //先对齐
    for(; child != child_flag; center ++){    
        if(center == center_path.end() ||   child == child_path.end() ){
            if(center == center_path.end()) ROS_INFO("center is end!!!!!");
            if(child == child_path.end()) ROS_INFO("child is end!!!!!");
            break;
        }

        if(abs(center->t - child->t) < 0.0001 || center->t > child->t ){  
            //add sequential edge  从约束帧到上次优化的结束帧
            Vector3d Pjs = {(child)->px, (child)->py, (child)->pz};
            Quaterniond Qjs = {(child)->qw, (child)->qx, (child)->qy, (child)->qz};
            n = (int)(child - child_path.begin());
            for(int j = 1; j<seq_n; j++){//j太大就没意义了，他们的相对位置的值就不准了
                if(child - child_last >=j || (child - child_path.begin()>=j && all_process ==1)
                || (child_last+1-child_path.begin()<=back_n )  && child - child_path.begin()>=j){
                    Vector3d Pis = {(child-j)->px, (child-j)->py, (child-j)->pz};
                    Quaterniond Qis = {(child-j)->qw, (child-j)->qx, (child-j)->qy, (child-j)->qz};
                    Vector3d pij = Qis.normalized().conjugate().toRotationMatrix()*( Pjs - Pis);
                    Quaterniond Qij = Qis.normalized().conjugate()*Qjs.normalized();
                    //ROS_INFO_STREAM("quaternion multiply: "<<Qij.x());
                    //Qij = Qis.toRotationMatrix().transpose()*Qjs.toRotationMatrix();
                    //ROS_INFO_STREAM("Matrix multiply: "<<Qij.x());
                    Vector3d i_v_ij = {child->vx - (child-j)->vx,
                                                child->vy - (child-j)->vy,
                                                child->vz - (child-j)->vz};
                    i_v_ij = Qis.normalized().conjugate().toRotationMatrix()*i_v_ij;
                    ceres::CostFunction *sequentfactor = sequnce_constrain::Create(pij, Qij, i_v_ij, weight, weight2);
                    problem.AddResidualBlock(sequentfactor,NULL, para_Pose[n-j], para_Pose[n], para_SpeedBias[n-j], para_SpeedBias[n]);
                    if(int(child - child_last) == 1-back_n && n>0 && all_process == 0 ){
                        //problem.SetParameterBlockConstant(euler_array[0]);
                        ROS_INFO_STREAM("set constant :"<<n-1);
                        problem.SetParameterBlockConstant(para_Pose[n-1]);
                        problem.SetParameterBlockConstant(para_SpeedBias[n-1]); 
                    }
                }
            }
            
            //降采样处理10hz
            cur_t = child->t;//计算的是对齐的数据的频率，就是可以添加运动学约束的频率
            if((1.0 / (cur_t - last_t) > Frequence) && last_t != 0 && Frequence !=0){
                child ++;
                continue;
                //ROS_INFO("skip!");
            }
            if(Frequence != 0 || child == child_flag-1 || center + 1 ==center_path.end()){
                k++;
                //对临边进行强化
                /***
                if(n >0)
                {
                    int j =1;
                    Vector3d Pis = {(child-j)->px, (child-j)->py, (child-j)->pz};
                    Quaterniond Qis = {(child-j)->qw, (child-j)->qx, (child-j)->qy, (child-j)->qz};
                    Vector3d pij = Qis.normalized().conjugate().toRotationMatrix()*( Pjs - Pis);
                    Quaterniond Qij = Qis.normalized().conjugate()*Qjs.normalized();
                    //ROS_INFO_STREAM("quaternion multiply: "<<Qij.x());
                    //Qij = Qis.toRotationMatrix().transpose()*Qjs.toRotationMatrix();
                    //ROS_INFO_STREAM("Matrix multiply: "<<Qij.x());
                    Vector3d vij = {(child-j)->vx - child->vx,
                                                (child-j)->vy - child->vy,
                                                (child-j)->vz - child->vz};
                    ceres::CostFunction *sequentfactor = sequnce_constrain::Create(pij, Qij, vij, weight3, weight2);
                    problem.AddResidualBlock(sequentfactor,NULL, para_Pose[n-j], para_Pose[n], para_SpeedBias[n-j], para_SpeedBias[n]);
                }
                ***/
                Matrix3d info =Time *  Matrix3d::Identity();
                //info =  ER.inverse().transpose() *info;
                Vector3d Pos = {center->px, center->py, center->pz};
                Quaterniond Qos = {center->qw, center->qx, center->qy, center->qz};
                Qos = Qos.normalized();
                Vector3d Vos = {center->vx, center->vy, center->vz};
                Vector3d Wos = {center->wx, center->wy, center->wz};
                Vector3d angular_velocity_buf = {child->wx, child->wy, child->wz};//经过了零偏的修正
                
                if(e2 == 1){
                    if(tr == 1){
                        //pose
                        //ROS_INFO("tr!!!");
                        Vector3d Pose_o = (Pos - Qos*Xoi);
                        //ROS_INFO("kinematic constrain!");
                        ceres::CostFunction* pose_function = KinematicPoseConstrain_T_e2::Create(
                                                            Xoi, Pose_o, info);
                        if(if_lossfunction ==1){
                            problem.AddResidualBlock(pose_function,loss_function, para_Pose[n], para_ET);
                        }else{
                            problem.AddResidualBlock(pose_function,NULL, para_Pose[n], para_ET);
                        }
                        //参数大小不对。pose是一个7size的数组，但是要求要3size的数组
                        //velocity
                        
                        Matrix3d Swo;
                        Swo << 0, -Wos(2), Wos(1),
                                        Wos(2), 0, -Wos(0),
                                        -Wos(1), Wos(0), 0;
                        //Vector3d Vo =R* (Vos - Qos*Swo*Xoi);
                        Vector3d Vo = (Vos - Qos*Swo*Xoi);
                        
                        ceres::CostFunction* velo_function = KinematicVeloConstrain_T_e2::Create(
                                                            Xoi, Vo, angular_velocity_buf, info);
                        problem.AddResidualBlock(velo_function, loss_function, para_SpeedBias[n], para_Pose[n], para_ET);
                    
                    }else{
                        //pose
                        Vector3d Pose_o = Pos - Qos*Xoi;
                        if(data_noise != 1){
                                Pose_o = R*(Pos - Qos*Xoi)+t;}
                        //ROS_INFO("kinematic constrain!");
                        ceres::CostFunction* pose_function = KinematicPoseConstrain_e2::Create(
                                                            Xoi, Pose_o, info);
                        if(if_lossfunction ==1){
                            problem.AddResidualBlock(pose_function, loss_function, para_Pose[n]);
                        }else{
                            problem.AddResidualBlock(pose_function, NULL, para_Pose[n]);
                        }
                        //参数大小不对。pose是一个7size的数组，但是要求要3size的数组
                        //velocity
                        
                        Matrix3d Swo;
                        Swo << 0, -Wos(2), Wos(1),
                                        Wos(2), 0, -Wos(0),
                                        -Wos(1), Wos(0), 0;
                        
                        Vector3d Vo = (Vos - Qos*Swo*Xoi);
                        if(data_noise != 1){
                            Vo =R* (Vos - Qos*Swo*Xoi);
                        }
                        ceres::CostFunction* velo_function = KinematicVeloConstrain_e2::Create(
                                                            Xoi, Vo, angular_velocity_buf, info);
                        if(if_lossfunction ==1){
                            problem.AddResidualBlock(velo_function, loss_function, para_SpeedBias[n], para_Pose[n]);
                        }else{
                            problem.AddResidualBlock(velo_function, NULL, para_SpeedBias[n], para_Pose[n]);
                        }
                        
                    }
                }
                else{
                    if(if_xoi==1){
                        //pose
                            
                        Vector3d Pose_o = (Pos );
                        //ROS_INFO("kinematic constrain!");
                        ceres::CostFunction* pose_function = KinematicPoseConstrain_T_x::Create(
                                                            Pose_o, Qos, info);
                        if(if_lossfunction ==1){
                            problem.AddResidualBlock(pose_function,loss_function, para_Pose[n], para_ET, delta_xio);
                        }else{
                            problem.AddResidualBlock(pose_function,NULL, para_Pose[n], para_ET, delta_xio);
                        }
                        //参数大小不对。pose是一个7size的数组，但是要求要3size的数组
                        //velocity
                        Vector3d Vo = (Vos );
                        
                        ceres::CostFunction* velo_function = KinematicVeloConstrain_T_x::Create(
                                                             Vo,Qos, angular_velocity_buf, Wos, info);
                        
                        if(if_lossfunction ==1){
                            problem.AddResidualBlock(velo_function, loss_function, para_SpeedBias[n], para_Pose[n], para_ET,delta_xio);
                        }else{
                            problem.AddResidualBlock(velo_function, NULL, para_SpeedBias[n], para_Pose[n], para_ET,delta_xio);
                        }
                    
                    }else{
                        if(tr == 1){
                            //pose
                            
                            Vector3d Pose_o = (Pos - Qos*Xoi);
                            //ROS_INFO("kinematic constrain!");
                            ceres::CostFunction* pose_function = KinematicPoseConstrain_T::Create(
                                                                Xoi, Pose_o, info);
                            if(if_lossfunction ==1){
                                problem.AddResidualBlock(pose_function,loss_function, para_Pose[n], para_ET);
                            }else{
                                problem.AddResidualBlock(pose_function,NULL, para_Pose[n], para_ET);
                            }
                            //参数大小不对。pose是一个7size的数组，但是要求要3size的数组
                            //velocity
                            
                            Matrix3d Swo;
                            Swo << 0, -Wos(2), Wos(1),
                                            Wos(2), 0, -Wos(0),
                                            -Wos(1), Wos(0), 0;
                            //Vector3d Vo =R* (Vos - Qos*Swo*Xoi);
                            Vector3d Vo = (Vos - Qos*Swo*Xoi);
                            
                            ceres::CostFunction* velo_function = KinematicVeloConstrain_T::Create(
                                                                Xoi, Vo, angular_velocity_buf, info);
                            
                            if(if_lossfunction ==1){
                                problem.AddResidualBlock(velo_function, loss_function, para_SpeedBias[n], para_Pose[n], para_ET);
                            }else{
                                problem.AddResidualBlock(velo_function, NULL, para_SpeedBias[n], para_Pose[n], para_ET);
                            }
                    
                        }else{      
                            //pose
                            
                            Vector3d Pose_o = (Pos - Qos*Xoi);
                            if(data_noise != 1){
                                Pose_o = R*(Pos - Qos*Xoi)+t;}
                            //Vector3d euler_i = Utility::R2ypr(Qjs.toRotationMatrix());
                            //ROS_INFO("kinematic constrain!");
                            ceres::CostFunction* pose_function = KinematicPoseConstrain::Create(
                                                            Xoi, Pose_o, info);
                            if(if_lossfunction ==1){
                                problem.AddResidualBlock(pose_function, loss_function, para_Pose[n]);
                            }else{
                                problem.AddResidualBlock(pose_function, NULL, para_Pose[n]);
                            }
                            //参数大小不对。pose是一个7size的数组，但是要求要3size的数组
                            //velocity
                            
                            Matrix3d Swo;
                            Swo << 0, -Wos(2), Wos(1),
                                            Wos(2), 0, -Wos(0),
                                            -Wos(1), Wos(0), 0;
                            //
                            Vector3d Vo = (Vos - Qos*Swo*Xoi);
                            if(data_noise != 1){
                                Vo =R* (Vos - Qos*Swo*Xoi);
                            }
                            ceres::CostFunction* velo_function = KinematicVeloConstrain::Create(
                                                            Xoi, Vo, angular_velocity_buf, info);
                            if(if_lossfunction ==1){
                                problem.AddResidualBlock(velo_function, loss_function, para_SpeedBias[n], para_Pose[n]);
                            }else{
                                problem.AddResidualBlock(velo_function, NULL, para_SpeedBias[n], para_Pose[n]);
                            }
                            /***
                         //手动求导
                            Vector3d Pose_o = (Pos - Qos*Xoi);
                            if(data_noise != 1){
                                Pose_o = R*(Pos - Qos*Xoi)+t;}
                            //Vector3d Pose_o = (Pos - Qos*Xoi);
                            //Vector3d euler_i = Utility::R2ypr(Qjs.toRotationMatrix());
                            //ROS_INFO("kinematic constrain!");
                            KinematicPoseFactor *f_p = new KinematicPoseFactor(
                                                            Xoi, Pose_o, info);
                            problem.AddResidualBlock(f_p, NULL, para_Pose[n]);
                            //参数大小不对。pose是一个7size的数组，但是要求要3size的数组
                            //velocity
                            
                            Matrix3d Swo;
                            Swo << 0, -Wos(2), Wos(1),
                                            Wos(2), 0, -Wos(0),
                                            -Wos(1), Wos(0), 0;
                            //Vector3d Vo =R* (Vos - Qos*Swo*Xoi);
                            Vector3d Vo = (Vos - Qos*Swo*Xoi);
                            if(data_noise != 1){
                                Vo =R* (Vos - Qos*Swo*Xoi);
                            }
                            KinematicVeloFactor *f_v = new KinematicVeloFactor(
                                                            Xoi, Vo, angular_velocity_buf, info);
                            problem.AddResidualBlock(f_v, NULL, para_Pose[n],  para_SpeedBias[n]);
                            ***/
                        }
                    }
                   
                }
            }
            child ++;
            last_t = cur_t;
        }
    }
    //优化前的值
    q_last = Quaterniond{(child-1)->qw, (child-1)->qx, (child-1)->qy, (child-1)->qz}.normalized();
    p_last = Vector3d{(child-1)->px, (child-1)->py, (child-1)->pz};
    ROS_INFO_STREAM("residualblock number: "<<k);
    //开始优化
    ceres::Solver::Options options;
    options.linear_solver_type = ceres::SPARSE_NORMAL_CHOLESKY;
    options.minimizer_progress_to_stdout = true;
    options.max_num_iterations = MAX_ITERATION_NUMBER;
    ceres::Solver::Summary summary;
    ROS_INFO("optimizating");
    ceres::Solve(options, &problem, &summary);
    std::cout << summary.BriefReport() << "\n";
    cout << summary.FullReport() << endl;
    //更新
    for(auto index = child_path.begin(); index<child; index++){
        k = index - child_path.begin();
        for(int m = 0; m<7; m++)    rect_Pose[k][m] = para_Pose[k][m];
        for(int m = 0; m<3; m++)    rect_SpeedBias[k][m] = para_SpeedBias[k][m];
        if(if_xoi == 1)
            for(int m = 0; m<3; m++)    Xoi[m] = delta_xio[m] ;
    }
    //计算优化前后的变化
    Matrix3d q_cur = Quaterniond{rect_Pose[n][6], rect_Pose[n][3], rect_Pose[n][4], rect_Pose[n][5]}.normalized().toRotationMatrix();
    Vector3d  p_cur = Vector3d{rect_Pose[n][0], rect_Pose[n][1], rect_Pose[n][2]};
    
    Quaterniond simq = Quaterniond(q_last.transpose()*q_cur); 
    Simq = simq.normalized();
    Simt = q_last.transpose()*(p_cur - p_last);
    /***
   Quaterniond simq = Quaterniond(q_cur*q_last.transpose()); 
    Simq = simq.normalized();
    Simt = (p_cur - Simq*p_last);
    ***/
    ROS_INFO_STREAM("child place: "<<int(child-child_path.begin()));
    ROS_INFO_STREAM("center place: "<<int(center-center_path.begin()));
    ROS_INFO_STREAM("Simq: "<<Simq);
    ROS_INFO_STREAM("Simt:"<<Simt);
    {
        ROS_INFO_STREAM("EX_t: "<<Vector3d(para_ET[0],para_ET[1],para_ET[2]));
        ROS_INFO_STREAM("delta value: "<< Vector3d(para_ET[0],para_ET[1],para_ET[2])-(t));
        ROS_INFO("EX_T:");
        Quaterniond Q_R;
        Q_R = R;
        Quaterniond ET_r = Quaterniond(para_ET[6],para_ET[3],para_ET[4],para_ET[5]).normalized();
        ROS_INFO_STREAM(" "<<ET_r.toRotationMatrix());
        Vector3d delta = 2 * (Q_R.normalized()* ET_r.conjugate()).vec();
        ROS_INFO("inital value:");
        ROS_INFO_STREAM(" "<<R);
        ROS_INFO("delta value:");
        ROS_INFO_STREAM(" "<<delta);
        ROS_INFO_STREAM("XOI_estimated: "<<Xoi);
    }
    if(center == center_path.end() ||   child_path.end() == child ){
            ROS_INFO("All data have optimized");
            return 0;
        }
    child_last = child-1;//-1是指处理了的位子
    if(all_process == 1){
        child = child_path.begin();
        center = center_path.begin();
        if(back_n !=0 ){
            child = child - back_n;
            if( child_last+1-child_path.begin()<=back_n)
                child = child_path.begin();
        }
    } 


    return 1;
}

void save_result(double para_Pose[][7], double para_SpeedBias[][9], double euler_array[][3],
                                        double rect_Pose[][7], double rect_SpeedBias[][9]){
        //保存优化结果
    ofstream foutC(save_path.c_str(), ios::app);
    child = child_path.begin();
    Eigen::Quaterniond Q(R);
    Matrix3d RR;
    RR = Q.inverse();
   Vector3d tt = -RR*t;
    for(; child != child_path.end(); child++){
        n = (int)(child - child_path.begin()); 
        Vector3d align_p = Vector3d(rect_Pose[n][0], rect_Pose[n][1], rect_Pose[n][2]);
        Vector3d align_v = Vector3d(rect_SpeedBias[n][0], rect_SpeedBias[n][1], rect_SpeedBias[n][2]);
        Quaterniond align_q = Quaterniond(rect_Pose[n][6], rect_Pose[n][3],  rect_Pose[n][4], rect_Pose[n][5]);
        if(Align == 1 && data_noise==0){
            
            align_p = RR*align_p + tt;
            align_v = RR*align_v;
            align_q = RR*align_q;
        }
        
        foutC.setf(ios::fixed, ios::floatfield);
        foutC.precision(0);
        foutC << child->t * 1e9 << ",";
        foutC.precision(5);
        foutC <<align_p[0] << "," << align_p[1] << "," <<align_p[2] << ","
        << align_q.w() << "," <<  align_q.x() << "," <<  align_q.y() << "," <<  align_q.z() << "," 
        << align_v[0] << "," << align_v[1]  << "," <<align_v[2]  << ","
        << 0 << "," << 0 << "," <<0<< ","
        << 0<< "," <<0 << "," <<0 << endl;
    }
    foutC.close();
    ROS_INFO_STREAM("results have been saved at "<<save_path.c_str());
    return;
    
}

int main(int argc, char **argv){
    ros::init(argc, argv, "offline_process");
    ros::NodeHandle nh("~");
    //通过launch文件读取数据文件的名字
    string center_csv = readParam<string>(nh, "center_data_name");
    string vins_csv = readParam<string>(nh, "child_data_name");
    string Fre;
    //读取yaml文件
    setting_file = readParam<string>(nh, "setting");
    cv::FileStorage fsSettings(setting_file.c_str(), cv::FileStorage::READ);
    fsSettings["output_name"]>>save_path;

    FILE *center_f = fopen(center_csv.c_str(), "r");
    
    if(center_f == NULL){
        ROS_WARN("can't load center path.");
        return 0;
    }
    FILE *child_f =fopen(vins_csv.c_str(), "r");
    if(child_f == NULL){
        ROS_WARN("can't load child path. ");
        return 0;
    }
    //读取文件内容
    while(!feof(center_f))
        center_path.emplace_back(center_f);
    
    fclose(center_f);
    while(!feof(child_f))
        child_path.emplace_back(child_f);
    ROS_INFO("Data loaded:   center = %d, child = %d", (int)center_path.size(), (int)child_path.size());
    //读取参数
    tr = fsSettings["tr_flag"];
    ROS_INFO_STREAM("tr: "<<tr);
    e2 = fsSettings["e2_flag"];
    ROS_INFO_STREAM("e2: "<<e2);
    Frequence = fsSettings["Fre"];
    ROS_INFO_STREAM("Fre: "<<Frequence);
    number = fsSettings["Number"];
    ROS_INFO_STREAM("iteration magnitude: "<<number);
    seq_n = fsSettings["seq_n"];
    ROS_INFO_STREAM("sequential edge: "<<seq_n);
    Time = fsSettings["Time"];
    ROS_INFO_STREAM("info_matrix: "<<Time);
    data_noise = fsSettings["data_noise"];
    ROS_INFO_STREAM("using data_noise.csv: "<<data_noise);
    weight = fsSettings["weight"];
    ROS_INFO_STREAM("sequential edge weight: "<<weight);
    weight2 = fsSettings["weight2"];
    ROS_INFO_STREAM("sequential q weight: "<<weight2);
    weight3 = fsSettings["weight3"];
    ROS_INFO_STREAM("enforced edge weight: "<<weight3);
    Align = fsSettings["align"];
    ROS_INFO_STREAM("align: "<<Align);
    processnumber = fsSettings["processnumber"];
    ROS_INFO_STREAM("process number: "<<processnumber);
    all_process = fsSettings["all_process"];
    ROS_INFO_STREAM("process all?: "<<all_process);
    back_n = fsSettings["back_n"];
    ROS_INFO_STREAM("back_n: "<<back_n);
    propagate = fsSettings["propagate"];
    ROS_INFO_STREAM("propagate: "<<propagate);
    MAX_ITERATION_NUMBER = fsSettings["max_iteration_number"];
    ROS_INFO_STREAM("max_iteration_number: "<<MAX_ITERATION_NUMBER);
    if_lossfunction = fsSettings["if_lossfunction"];
    ROS_INFO_STREAM("if_lossfunction: "<<if_lossfunction);
    if_xoi = fsSettings["if_xoi"];
    ROS_INFO_STREAM("if_xoi: "<<if_xoi);
    //R_imu_gt
    cv::Mat cv_ER, cv_ET, cv_xoi;
    fsSettings["extrinsicR"] >> cv_ER;
    fsSettings["extrinsicT"] >> cv_ET;
    fsSettings["Xoi"] >> cv_xoi;
    cv::cv2eigen(cv_ER, R);
    cv::cv2eigen(cv_ET, t);
    cv::cv2eigen(cv_xoi, Xoi);
    ROS_INFO_STREAM("Xoi:"<<Xoi);
    //优化初值
    delta_xio[0] = Xoi.x(); delta_xio[1] = Xoi.y(); delta_xio[2] = Xoi.z();
    Eigen::Quaterniond EQ(R);
    R = EQ.normalized();
    ROS_INFO_STREAM("R_imu_gt:"<<R);
    ROS_INFO_STREAM("t:"<<t);
    Quaterniond Q = Quaterniond(R);
    para_ET[0] = t.x(); para_ET[1] = t.y(); para_ET[2] = t.z();
    para_ET[3] = Q.x(); para_ET[4] = Q.y(); para_ET[5] = Q.z(); para_ET[6] = Q.w();
    if(tr == 1){
        para_ET[0] = 0; para_ET[2] = 0; para_ET[1] = 0;
        para_ET[3] = 0; para_ET[4] = 0; para_ET[5] = 0; para_ET[6] = 1;
    }
    {
        Matrix3d ET_r ;
        ET_r= Quaterniond(para_ET[6],para_ET[3],para_ET[4],para_ET[5]);
        ROS_INFO_STREAM(" "<<ET_r);
    }
    ROS_INFO_STREAM("EX_t: "<<Vector3d(para_ET[0],para_ET[1],para_ET[2]));
    
    
    //优化用的double数组
    double para_Pose[(int)child_path.size()][7];//xyz,qx,qy,qz,qw
    double para_SpeedBias[(int)child_path.size()][9];
    double rect_Pose[(int)child_path.size()][7];//xyz,qx,qy,qz,qw
    double rect_SpeedBias[(int)child_path.size()][9];
    double euler_array[(int)child_path.size()][3];
    child = child_path.begin(); 
    center = center_path.begin();
    
    for(; child != child_path.end(); child++){
        n = (int)(child - child_path.begin()); 
        //ROS_INFO_STREAM("n: "<<n);
        para_Pose[n][0] = child->px; para_Pose[n][1] = child->py; para_Pose[n][2] = child->pz;
        para_Pose[n][3] = child->qx; para_Pose[n][4] = child->qy; para_Pose[n][5] = child->qz; para_Pose[n][6] = child->qw;
        para_SpeedBias[n][0] = child->vx; para_SpeedBias[n][1] = child->vy; para_SpeedBias[n][2] = child->vz;
        for(int i =3;i<9;i++ ) para_SpeedBias[n][i] = 0;
        rect_Pose[n][0] = child->px; rect_Pose[n][1] = child->py; rect_Pose[n][2] = child->pz;
        rect_Pose[n][3] = child->qx; rect_Pose[n][4] = child->qy; rect_Pose[n][5] = child->qz; rect_Pose[n][6] = child->qw;
        rect_SpeedBias[n][0] = child->vx; rect_SpeedBias[n][1] = child->vy; rect_SpeedBias[n][2] = child->vz;
        for(int i =3;i<9;i++ ) rect_SpeedBias[n][i] = 0;
        Vector3d euler_angle = Utility::R2ypr(Quaterniond(child->qw, child->qx, child->qy, child->qz).toRotationMatrix());
        euler_array[n][0] = euler_angle.x();
        euler_array[n][1] = euler_angle.y();
        euler_array[n][2] = euler_angle.z();
    }
    
    ROS_INFO("initialization over!");
    child = child_path.begin();
    n = 0;
    child_flag = child;
    child_last = child;
    ROS_INFO_STREAM("child position: "<<child - child_path.begin());
    
    while(process(para_Pose, para_SpeedBias, euler_array, rect_Pose, rect_SpeedBias) ==1){
        //每次优化后，把没优化的部分进行修正
        if(propagate ==1){
            for(int i = n+1; i < child_path.size(); i++){
                Matrix3d  rec_r= Quaterniond{(child_path.begin()+i)->qw, (child_path.begin()+i)->qx, (child_path.begin()+i)->qy, (child_path.begin()+i)->qz}.normalized().toRotationMatrix();
                Vector3d  rec_t = Vector3d{(child_path.begin()+i)->px, (child_path.begin()+i)->py, (child_path.begin()+i)->pz};
                Vector3d rec_v = Vector3d{(child_path.begin()+i)->vx, (child_path.begin()+i)->vy, (child_path.begin()+i)->vz};
                 
                rec_t = rec_r*Simt +rec_t;
                rec_r = rec_r*Simq;
                rec_v = rec_v;
                Quaterniond rec_q(rec_r);
                rec_q = rec_q.normalized();
               /***
                rec_t = Simq*rec_t + Simt;
                rec_r = Simq*rec_r;
                rec_v = rec_v;
                Quaterniond rec_q(rec_r);
                rec_q = rec_q.normalized();
                ***/
                rect_Pose[i][0] = rec_t.x(); rect_Pose[i][1] =rec_t.y(); rect_Pose[i][2] = rec_t.z();
                rect_Pose[i][3] = rec_q.x(); rect_Pose[i][4] = rec_q.y(); rect_Pose[i][5] = rec_q.z(); rect_Pose[i][6] = rec_q.w();
                rect_SpeedBias[i][0] = rec_v.x(); rect_SpeedBias[i][1] = rec_v.y(); rect_SpeedBias[i][2] = rec_v.z();
            }
        }
        processnumber --;
        if(processnumber>=0)
            break;
    };

    save_result(para_Pose, para_SpeedBias, euler_array, rect_Pose, rect_SpeedBias);
    return 0;
}